"""
Package for lab7q2.
"""
