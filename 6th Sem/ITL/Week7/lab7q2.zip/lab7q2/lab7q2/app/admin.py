from django.contrib import admin
import site
from app.models import Works, Lives

admin.site.register(Works)
admin.site.register(Lives)

