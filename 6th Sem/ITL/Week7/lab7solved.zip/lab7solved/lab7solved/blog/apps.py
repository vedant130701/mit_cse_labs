from django.apps import AppConfig


class blogAppConfig(AppConfig):
    name = 'blogApp'
