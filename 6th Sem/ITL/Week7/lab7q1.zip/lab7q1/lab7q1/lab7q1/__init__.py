"""
Package for lab7q1.
"""
