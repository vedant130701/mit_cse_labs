from django.contrib import admin
import site
from app.models import Category, Page

admin.site.register(Category)
admin.site.register(Page)
