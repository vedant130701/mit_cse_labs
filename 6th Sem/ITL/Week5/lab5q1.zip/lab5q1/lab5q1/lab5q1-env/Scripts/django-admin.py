#!D:\190905160\lab5\lab5q1\lab5q1\lab5q1-env\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
