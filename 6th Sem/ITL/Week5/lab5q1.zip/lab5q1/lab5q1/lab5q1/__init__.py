"""
Package for lab5q1.
"""
