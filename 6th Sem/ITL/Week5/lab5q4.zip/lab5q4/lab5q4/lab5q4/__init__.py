"""
Package for lab5q4.
"""
