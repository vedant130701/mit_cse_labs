"""
Package for lab5q3.
"""
