"""
Package for lab5q2.
"""
