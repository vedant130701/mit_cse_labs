"""
Package for lab6q3.
"""
