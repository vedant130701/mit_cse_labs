"""
Package for lab6q4.
"""
