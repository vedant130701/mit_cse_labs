#!C:\Users\vedan\OneDrive\Documents\2nd Year\3rd year\ITL\Week6\lab6q1\lab6q1\lab6q1-env\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
