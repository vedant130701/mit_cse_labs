"""
Package for lab6q1.
"""
