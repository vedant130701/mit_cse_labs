"""
Package for lab6q2.
"""
